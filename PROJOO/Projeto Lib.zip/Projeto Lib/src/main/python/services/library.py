# src/main/python/services/library.py

from models.book import Book
from models.user import User

class Library:
    def __init__(self):
        self.books = []
        self.users = []

    def add_book(self, book):
        # Adiciona um novo livro à biblioteca
        self.books.append(book)

    def search_book(self, title):
        # Busca um livro pelo título
        for book in self.books:
            if book.title == title:
                return book
        return None

    def borrow_book(self, user_id, book_title):
        # Realiza o empréstimo de um livro para um usuário específico
        user = self._find_user_by_id(user_id)
        book = self.search_book(book_title)
        if user and book and book.is_available:
            user.borrow_book(book)
            return True
        return False

    def return_book(self, user_id, book_title):
        # Realiza a devolução de um livro emprestado por um usuário específico
        user = self._find_user_by_id(user_id)
        book = self.search_book(book_title)
        if user and book:
            user.return_book(book)
            return True
        return False

    def _find_user_by_id(self, user_id):
        # Busca um usuário pelo ID
        for user in self.users:
            if user.user_id == user_id:
                return user
        return None
