# src/main/python/models/user.py

class User:
    def __init__(self, name, user_id):
        self.name = name
        self.user_id = user_id
        self.borrowed_books = []

    def borrow_book(self, book):
        # Verifica se o livro está disponível e adiciona à lista de livros emprestados
        if book.is_available:
            self.borrowed_books.append(book)
            book.is_available = False

    def return_book(self, book):
        # Remove o livro da lista de livros emprestados e marca como disponível
        if book in self.borrowed_books:
            self.borrowed_books.remove(book)
            book.is_available = True

    def __str__(self):
        return f"User: {self.name}, ID: {self.user_id}, Borrowed Books: {[book.title for book in self.borrowed_books]}"
