import json
from flask import Flask, render_template, request, redirect, url_for, flash
from services.library_facade import LibraryFacade
from models.user import User
from models.book import Book

app = Flask(__name__)
app.secret_key = 'your_secret_key'

library_facade = LibraryFacade()

# Função para carregar livros do arquivo JSON
def load_books_from_json():
    with open('books.json', 'r') as file:
        books_data = json.load(file)
        for book_data in books_data:
            book = Book(book_data['title'], book_data['author'], book_data['category'])
            library_facade.library.add_book(book)

# Função para carregar usuários de teste
def load_test_users():
    users = [
        User("Raissa", "1"),
        User("Melissa", "2"),
        User("Fabio", "3"),
        User("Enzo", "4"),
        User("David", "5")
    ]
    library_facade.library.users.extend(users)

# Carregar livros e usuários na inicialização
load_books_from_json()
load_test_users()

# Rotas
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        title = request.form['title']
        book = library_facade.search_book(title)
        if book:
            return render_template('search.html', book=book)
        else:
            flash('Book not found.')
            return redirect(url_for('search'))
    return render_template('search.html', book=None)

@app.route('/borrow', methods=['GET', 'POST'])
def borrow():
    if request.method == 'POST':
        user_id = request.form['user_id']
        book_title = request.form['book_title']
        if library_facade.borrow_book(user_id, book_title):
            flash('Book borrowed successfully.')
        else:
            flash('Failed to borrow book.')
        return redirect(url_for('borrow'))
    return render_template('borrow.html')

@app.route('/return', methods=['GET', 'POST'])
def return_book():
    if request.method == 'POST':
        user_id = request.form['user_id']
        book_title = request.form['book_title']
        if library_facade.return_book(user_id, book_title):
            flash('Book returned successfully.')
        else:
            flash('Failed to return book.')
        return redirect(url_for('return_book'))
    return render_template('return.html')

@app.route('/users')
def users():
    return render_template('users.html', users=library_facade.library.users)

if __name__ == '__main__':
    app.run(debug=True)
