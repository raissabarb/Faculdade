# src/main/python/services/library_facade.py

from services.library import Library
from models.book import Book

class LibraryFacade:
    def __init__(self):
        self.library = Library()

    def add_book(self, title, author, category):
        # Interface simplificada para adicionar um livro
        book = Book(title, author, category)
        self.library.add_book(book)

    def search_book(self, title):
        # Interface simplificada para buscar um livro
        return self.library.search_book(title)

    def borrow_book(self, user_id, book_title):
        # Interface simplificada para emprestar um livro
        return self.library.borrow_book(user_id, book_title)

    def return_book(self, user_id, book_title):
        # Interface simplificada para devolver um livro
        return self.library.return_book(user_id, book_title)
